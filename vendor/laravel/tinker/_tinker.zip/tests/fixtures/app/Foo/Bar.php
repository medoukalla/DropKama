<?php

namespace App\Foo;

class Bar
{
    //
}
