<?php

namespace App\Baz;

class Qux
{
    //
}
